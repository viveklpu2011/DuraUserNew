﻿using System;
using DuraApp.Core.Models.Common;

namespace DuraApp.Core.Models.ResponseModels
{
    public class DeleteDocumentResponseModel : CommonResponseModel
    {
        public int data { get; set; }
    }
}
