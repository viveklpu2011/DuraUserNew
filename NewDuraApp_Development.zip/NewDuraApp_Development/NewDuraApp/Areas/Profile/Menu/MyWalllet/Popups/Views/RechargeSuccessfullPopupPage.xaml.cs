﻿using System;
using System.Collections.Generic;
using Rg.Plugins.Popup.Pages;
using Xamarin.Forms;

namespace NewDuraApp.Areas.Profile.Menu.MyWalllet.Popups.Views
{
    public partial class RechargeSuccessfullPopupPage : PopupPage
    {
        public RechargeSuccessfullPopupPage()
        {
            InitializeComponent();
        }
    }
}
