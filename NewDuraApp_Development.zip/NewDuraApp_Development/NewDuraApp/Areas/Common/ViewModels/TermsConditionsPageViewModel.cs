﻿using NewDuraApp.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace NewDuraApp.Areas.Common.ViewModels
{
   public class TermsConditionsPageViewModel: AppBaseViewModel
    {
    }
}
