﻿using System;
using Xamarin.Forms;

namespace NewDuraApp.Models
{
    public class DuraEatsBannerModel
    {
        public int Id { get; set; }
        public ImageSource ImageName { get; set; }
    }
}
