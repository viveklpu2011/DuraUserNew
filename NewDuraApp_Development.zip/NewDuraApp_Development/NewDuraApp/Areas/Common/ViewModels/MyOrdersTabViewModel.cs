﻿using NewDuraApp.ViewModels;

namespace NewDuraApp.Areas.Common.ViewModels
{
	public class MyOrdersTabViewModel : AppBaseViewModel
	{
	}
}
