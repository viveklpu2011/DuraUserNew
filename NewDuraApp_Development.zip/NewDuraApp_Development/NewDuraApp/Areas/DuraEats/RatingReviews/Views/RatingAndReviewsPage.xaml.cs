﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NewDuraApp.Areas.DuraEats.RatingReviews.Views
{
    public partial class RatingAndReviewsPage : ContentPage
    {
        public RatingAndReviewsPage()
        {
            InitializeComponent();
        }
    }
}
