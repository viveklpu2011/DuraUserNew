﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NewDuraApp.Areas.Profile.Menu.MyAddress.Views
{
    public partial class MyAddressPage : ContentPage
    {
        public MyAddressPage()
        {
            InitializeComponent();
        }
    }
}
