﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NewDuraApp.Areas.Common.Views
{
    public partial class ApplyPromoCodePage : ContentPage
    {
        public ApplyPromoCodePage()
        {
            InitializeComponent();
        }
    }
}
