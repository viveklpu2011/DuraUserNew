﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NewDuraApp.Areas.DuraEats.Home.Views
{
    public partial class DuraEatsHomePage : ContentPage
    {
        public DuraEatsHomePage()
        {
            InitializeComponent();
        }
    }
}
