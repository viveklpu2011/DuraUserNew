﻿using System;
using Xamarin.Forms;

namespace NewDuraApp.Controls
{
    public class CustomRadioBtton:RadioButton
    {
        
    }
}
