﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NewDuraApp.Areas.DuraEats.PaymentMethod.Views
{
    public partial class PaymentModePage : ContentPage
    {
        public PaymentModePage()
        {
            InitializeComponent();
        }
    }
}
