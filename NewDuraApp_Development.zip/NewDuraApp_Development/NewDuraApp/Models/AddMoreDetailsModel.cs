﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewDuraApp.Models
{
    public class AddMoreDetailsModel
    {
        public string Account { get; set; }
        public int Index { get; set; }
    }
}
