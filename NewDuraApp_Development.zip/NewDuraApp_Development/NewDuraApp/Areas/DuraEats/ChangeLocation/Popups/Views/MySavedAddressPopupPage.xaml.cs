﻿using System;
using System.Collections.Generic;
using Rg.Plugins.Popup.Pages;
using Xamarin.Forms;

namespace NewDuraApp.Areas.DuraEats.ChangeLocation.Popups.Views
{
    public partial class MySavedAddressPopupPage : PopupPage
    {
        public MySavedAddressPopupPage()
        {
            InitializeComponent();
        }
    }
}
