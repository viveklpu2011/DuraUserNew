﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NewDuraApp.Areas.Profile.Menu.SavedCards.Views
{
    public partial class SavedCardsListPage : ContentPage
    {
        public SavedCardsListPage()
        {
            InitializeComponent();
        }
    }
}
