﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NewDuraApp.Areas.DuraEats.MyCart.Views
{
    public partial class MyCartPage : ContentPage
    {
        public MyCartPage()
        {
            InitializeComponent();
        }
    }
}
