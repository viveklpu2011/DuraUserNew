﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NewDuraApp.Areas.Profile.Menu.MyWalllet.Views
{
    public partial class AddMoneyPage : ContentPage
    {
        public AddMoneyPage()
        {
            InitializeComponent();
        }
    }
}
