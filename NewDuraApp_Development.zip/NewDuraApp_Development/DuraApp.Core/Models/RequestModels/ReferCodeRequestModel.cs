﻿using System;
namespace DuraApp.Core.Models.RequestModels
{
    public class ReferCodeRequestModel
    {
        public string refer_code { get; set; }
    }
}
