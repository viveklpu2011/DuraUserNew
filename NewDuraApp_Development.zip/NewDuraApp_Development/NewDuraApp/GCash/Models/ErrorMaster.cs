﻿using System;
namespace NewDuraApp.GCash.Models
{
    public class ErrorMaster
    {
        public string code { get; set; }
        public string detail { get; set; }
    }
}
