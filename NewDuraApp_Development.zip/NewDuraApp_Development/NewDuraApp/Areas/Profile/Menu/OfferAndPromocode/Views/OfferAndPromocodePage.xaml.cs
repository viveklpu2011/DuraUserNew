﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NewDuraApp.Areas.Profile.Menu.OfferAndPromocode.Views
{
    public partial class OfferAndPromocodePage : ContentPage
    {
        public OfferAndPromocodePage()
        {
            InitializeComponent();
        }
    }
}
