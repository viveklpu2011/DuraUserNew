﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NewDuraApp.Areas.Profile.Views
{
    public partial class BusinessDocumentUploadPage : ContentPage
    {
        public BusinessDocumentUploadPage()
        {
            InitializeComponent();
        }
    }
}
