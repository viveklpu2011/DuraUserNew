﻿using System;
namespace NewDuraApp.Models
{
    public class PromoCodeModel
    {
        public long PromocodeId { get; set; }
        public string Heding { get; set; }
        public string Validity { get; set; }
        public string Promocode { get; set; }
    }
}
