﻿using System;
namespace DuraApp.Core.Models.Common
{
    public class UploadImageTypeModel
    {
        public int Id { get; set; }
        public string ImageName { get; set; }
        public string UploadType { get; set; }
    }
}
