﻿using System;
namespace DuraApp.Core.Models.Common
{
    public class DuraAddressCommonModel
    {
        public string PickupType { get; set; }
        public string PickupDate { get; set; }
    }
}
