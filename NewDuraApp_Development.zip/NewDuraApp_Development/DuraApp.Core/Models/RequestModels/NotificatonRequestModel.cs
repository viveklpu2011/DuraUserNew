﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DuraApp.Core.Models.RequestModels
{
   public class NotificatonRequestModel
    {
        public int user_id { get; set; }
    }
}