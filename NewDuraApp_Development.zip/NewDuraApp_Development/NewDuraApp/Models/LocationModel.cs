﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewDuraApp.Models
{
    public class LocationModel
    {
        public string Location { get; set; }
        public string AddressLocation { get; set; }
    }
}
