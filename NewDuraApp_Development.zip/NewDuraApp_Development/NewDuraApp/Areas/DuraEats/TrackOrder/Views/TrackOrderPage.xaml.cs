﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NewDuraApp.Areas.DuraEats.TrackOrder.Views
{
    public partial class TrackOrderPage : ContentPage
    {
        public TrackOrderPage()
        {
            InitializeComponent();
        }
    }
}
