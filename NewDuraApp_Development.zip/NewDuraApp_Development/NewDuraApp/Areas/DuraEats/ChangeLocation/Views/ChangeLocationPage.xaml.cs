﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NewDuraApp.Areas.DuraEats.ChangeLocation.Views
{
    public partial class ChangeLocationPage : ContentPage
    {
        public ChangeLocationPage()
        {
            InitializeComponent();
        }
    }
}
