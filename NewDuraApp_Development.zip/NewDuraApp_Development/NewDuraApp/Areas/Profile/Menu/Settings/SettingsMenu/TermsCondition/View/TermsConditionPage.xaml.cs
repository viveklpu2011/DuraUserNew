﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NewDuraApp.Areas.Profile.Menu.Settings.SettingsMenu.TermsCondition.View
{
    public partial class TermsConditionPage : ContentPage
    {
        public TermsConditionPage()
        {
            InitializeComponent();
        }
    }
}
