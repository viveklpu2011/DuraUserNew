﻿using System;
using DuraApp.Core.Models.Common;

namespace DuraApp.Core.Models.ResponseModels
{
    public class FindDriverResponseModel : CommonResponseModel
    {
        public string data { get; set; }
    }
}
