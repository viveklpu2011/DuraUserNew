﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewDuraApp.Interfaces
{
    public interface IRootView
    {
    }
}
