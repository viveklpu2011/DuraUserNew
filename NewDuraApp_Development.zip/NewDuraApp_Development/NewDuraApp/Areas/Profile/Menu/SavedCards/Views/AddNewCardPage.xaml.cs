﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NewDuraApp.Areas.Profile.Menu.SavedCards.Views
{
    public partial class AddNewCardPage : ContentPage
    {
        public AddNewCardPage()
        {
            InitializeComponent();
        }
    }
}
