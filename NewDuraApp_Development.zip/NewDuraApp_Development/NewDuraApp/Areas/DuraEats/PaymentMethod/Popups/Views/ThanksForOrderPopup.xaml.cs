﻿using System;
using System.Collections.Generic;
using Rg.Plugins.Popup.Pages;
using Xamarin.Forms;

namespace NewDuraApp.Areas.DuraEats.PaymentMethod.Popups.Views
{
    public partial class ThanksForOrderPopup : PopupPage
    {
        public ThanksForOrderPopup()
        {
            InitializeComponent();
        }
    }
}
