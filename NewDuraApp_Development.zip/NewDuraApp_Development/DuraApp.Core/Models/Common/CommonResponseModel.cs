﻿using System;
namespace DuraApp.Core.Models.Common
{
    public class CommonResponseModel
    {
        public int status { get; set; }
        public string message { get; set; }
    }
}
