﻿using System;
namespace NewDuraApp.Helpers.GeoCoder
{
    public class LocationGeoCoder
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }
}
