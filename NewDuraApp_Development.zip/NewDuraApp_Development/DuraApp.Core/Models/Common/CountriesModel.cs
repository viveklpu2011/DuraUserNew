﻿using System;
namespace DuraApp.Core.Models.Common
{
    
    public class Countries
    {
        public string name { get; set; }
        public string dial_code { get; set; }
        public string code { get; set; }
    }
}
