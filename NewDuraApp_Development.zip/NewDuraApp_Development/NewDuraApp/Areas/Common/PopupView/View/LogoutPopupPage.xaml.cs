﻿using System;
using System.Collections.Generic;
using Rg.Plugins.Popup.Pages;
using Xamarin.Forms;

namespace NewDuraApp.Areas.Common.PopupView.View
{
    public partial class LogoutPopupPage : PopupPage
    {
        public LogoutPopupPage()
        {
            InitializeComponent();
        }
    }
}
