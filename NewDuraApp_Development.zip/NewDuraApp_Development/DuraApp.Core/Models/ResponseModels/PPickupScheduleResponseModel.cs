﻿using System;
using DuraApp.Core.Models.Common;

namespace DuraApp.Core.Models.ResponseModels
{
    public class PickupScheduleResponseModel : CommonResponseModel
    {
        public long data { get; set; }
    }
}
