﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NewDuraApp.Areas.Profile.Menu.ReferFriend.Views
{
    public partial class ReferAFriendPage : ContentPage
    {
        public ReferAFriendPage()
        {
            InitializeComponent();
        }
    }
}
