﻿using System;
using System.Collections.Generic;
using Rg.Plugins.Popup.Pages;
using Xamarin.Forms;

namespace NewDuraApp.Areas.DuraExpress.Popup.View
{
    public partial class AddRatingPopupPage : PopupPage
    {
        public AddRatingPopupPage()
        {
            InitializeComponent();
        }
    }
}
