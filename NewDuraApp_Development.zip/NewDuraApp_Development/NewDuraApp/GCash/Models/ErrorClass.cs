﻿using System;
using System.Collections.Generic;

namespace NewDuraApp.GCash.Models
{
    public class ErrorClass
    {
        public List<ErrorMaster> errors { get; set; }
    }
}
