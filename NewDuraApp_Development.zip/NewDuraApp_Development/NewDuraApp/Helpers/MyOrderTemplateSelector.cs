﻿using System;
namespace NewDuraApp.Helpers
{
    public class MyOrderTemplateSelector
    {
        public MyOrderTemplateSelector()
        {
        }
    }
}
