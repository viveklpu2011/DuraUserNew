﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace NewDuraApp.Areas.Orders.Views
{
    public partial class StopLocationView : ContentView
    {
        public StopLocationView()
        {
            InitializeComponent();
        }
    }
}
