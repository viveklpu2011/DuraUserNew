﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewDuraApp.Models
{
   public class NotificationModel
    {
        public string Notification { get; set; }
    }
}
