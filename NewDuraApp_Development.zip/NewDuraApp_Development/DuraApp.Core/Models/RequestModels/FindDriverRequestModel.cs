﻿using System;
namespace DuraApp.Core.Models.RequestModels
{
    public class FindDriverRequestModel
    {
        public long pickup_id { get; set; }
    }
}
