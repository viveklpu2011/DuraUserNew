﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NewDuraApp.Areas.Profile.Views
{
    public partial class PersonalDocumentUploadPage : ContentPage
    {
        public PersonalDocumentUploadPage()
        {
            InitializeComponent();
        }
    }
}
