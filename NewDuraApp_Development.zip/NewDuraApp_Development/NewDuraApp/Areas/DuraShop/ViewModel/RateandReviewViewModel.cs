﻿using NewDuraApp.Controls;
using NewDuraApp.ViewModels;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace NewDuraApp.Areas.DuraShop.ViewModel
{
    public class RateandReviewViewModel : AppBaseViewModel
    {
    }
}
