﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace NewDuraApp.Controls
{
    public class BorderlessPicker : Picker
    {
    }
}
