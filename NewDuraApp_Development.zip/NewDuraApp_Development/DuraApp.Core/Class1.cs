﻿using System;

namespace DuraApp.Core
{
    public class Class1
    {
    }
}
