﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NewDuraApp.Areas.Profile.Menu.Reviews.Views
{
    public partial class MyReviewsPage : ContentPage
    {
        public MyReviewsPage()
        {
            InitializeComponent();
        }
    }
}
