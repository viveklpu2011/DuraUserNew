﻿using System;
namespace NewDuraApp.Models
{
    public class TopUpAmountModel
    {
        public int TopupId { get; set; }
        public long Amount { get; set; }
        public string Backgrondcolor { get; set; }
        public string Bordercolor { get; set; }
    }
}
