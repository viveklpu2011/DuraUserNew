﻿using System;
namespace DuraApp.Core.Models.RequestModels
{
    public class CommonUserIdRequestModel
    {
        public long user_id { get; set; }
    }
}
