﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NewDuraApp.Areas.Profile.Menu.Settings.SettingsMenu.StandardRates.Views
{
    public partial class StandardRatesPage : ContentPage
    {
        public StandardRatesPage()
        {
            InitializeComponent();
        }
    }
}
