﻿using System;
using DuraApp.Core.Models.Common;

namespace DuraApp.Core.Models.Auth.ResponseModel
{
    public class ResetPasswordResponseModel : CommonResponseModel
    {
        public object data { get; set; }
    }
}
