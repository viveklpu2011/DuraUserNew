﻿using System;
using Xamarin.Auth;

namespace NewDuraApp.SocialLogin.AuthHelpers
{
    public class AuthenticationState
    {
        public static OAuth2Authenticator Authenticator;
    }
}
