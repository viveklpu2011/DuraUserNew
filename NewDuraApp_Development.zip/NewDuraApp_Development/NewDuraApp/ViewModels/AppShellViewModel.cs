﻿namespace NewDuraApp.ViewModels
{
    public class AppShellViewModel : AppBaseViewModel
    {
       
    }
}
