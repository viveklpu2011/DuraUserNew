﻿using System;
using System.Collections.Generic;
using Rg.Plugins.Popup.Pages;
using Xamarin.Forms;

namespace NewDuraApp.Areas.DuraEats.ItemDetails.Popups.Views
{
    public partial class ItemsDetailAddCartPopup  : PopupPage
    {
        public ItemsDetailAddCartPopup()
        {
            InitializeComponent();
        }
    }
}
