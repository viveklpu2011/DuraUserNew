﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace NewDuraApp.Models
{
    public class VehicleModel
    {
        public string VehicleDetails { get; set; }
        public ImageSource VehicleImage { get; set; }
    }
}
